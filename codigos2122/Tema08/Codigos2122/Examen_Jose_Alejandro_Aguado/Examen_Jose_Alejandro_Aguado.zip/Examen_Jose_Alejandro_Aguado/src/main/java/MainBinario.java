import controllerBin.LecturaBinario;

public class MainBinario {

    public static void main(String[] args) {

        LecturaBinario lecturaBinario = new LecturaBinario();

        lecturaBinario.controladorBinario();
    }
}
