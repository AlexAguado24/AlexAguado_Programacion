public class ExcepcionComensales extends Exception {
    public ExcepcionComensales(String message) {
        super(message);
    }
}
