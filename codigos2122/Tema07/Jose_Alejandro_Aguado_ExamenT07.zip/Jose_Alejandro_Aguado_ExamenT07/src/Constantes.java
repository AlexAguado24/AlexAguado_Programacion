public interface Constantes {

    double IVA_BEBIDAS = 1.21;
    double IVA_COMIDAS = 1.10;

    String CIF = "123123123A";
}
